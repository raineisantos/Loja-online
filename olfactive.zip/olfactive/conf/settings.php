<?php

define("DB_HOST", "localhost");

define("DB_USER", "root");

define("DB_PASS", "03215554");

define("DB_NAME", "olfactive");

define("SOUCEID", "22638329");

define("APPID", "564771466d477a4458664d3d");




//CONFIGURA��ES //



define("TAGS", "olfactive, desconto");

define("DESCRICAO", "Escolha uma de nossas milhares de ofertas e tenha uma �tima compra");

define("TITULO", ".:: Escolha uma de nossas milhares de ofertas e tenha uma �tima compra ::.");

define("EMPRESA", "Olfactive");

define("URL", "http://localhost/olfactive/");

define("IMAGENS", "http://localhost/olfactive/img/");

define("RODAPE", "Todos os direitos reservados");

define("CHARSET", "iso-8859-1");



?>
