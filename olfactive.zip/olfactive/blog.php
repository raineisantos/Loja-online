<?php
ini_set('error_reporting', 0);
ini_set('display_errors', 0);
session_start();
ob_start();
require_once('conexao.php');
//require_once('functions.php');
require_once('conf/settings.php');
include('conf/sec.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<title>Web Shop</title>
<? include('inc/head.php'); ?>
<? include('inc/mailmenu.php'); ?>

</head>
<body>


<? include('inc/header.php');?>
<? include('inc/menu.php');?>
<? include('inc/megamenu.php');?>
			
			
			
		</div>
	</div>

	<div id="content">
	
		<div class="content-top"></div>
		<div class="content-inner">
			
			<!-- List Begin -->
			
			<div class="breadcrumbs">
				<ul>
					<li><a href="index.html">Home</a></li>
					<li class="last">Blog</li>
				</ul>
				<br class="clear"/>
			</div>
			
			<!-- Left Column Begin -->
			<div class="left-side float-left">
				<h3><a href="<?=URL?>">Categorias</a></h3>
				<ul>

<?php
		$query = mysql_query("SELECT * FROM olfactive_categorias order by nome asc");
		$pos = 1;
      	while ($arr = mysql_fetch_array($query)) {

	$nome = $arr["nome"];
	$id = $arr["id"];

		?>
        <li><a href="<?=URL?>categoria.php?id=<?=urlencode("$nome")?>"> <span></span> <?=$nome?></a></li>
        <?
        $pos++;
}	?>
	
				</ul>
				
				<h3>Arquivo</h3>
				<ul>
					<li><a href="blog.html">2011</a></li>
					<li><a href="blog.html">2012</a></li>
					<li><a href="blog.html">2003</a></li>
				</ul>
				
				<!-- Latest Posts Begin -->
				<h3>Últimas mensagens do blog</h3>
				<div class="latest-comments">
					<div class="image-container float-left">
						<img src="images/small_blog2.jpg" alt="image"/>
					</div>
					
					<div class="comment-text">
						<a href="blog_single.html">Nunc porta turpis vitae tellus pulvinar dapibus.</a>
						<p>Janeiro 12, 2013</p>
					</div>
					<br class="clear"/>
				</div>
				
				<div class="latest-comments">
					<div class="image-container float-left">
						<img src="images/small_blog1.jpg" alt="image"/>
					</div>
					
					<div class="comment-text">
						<a href="blog_single.html">Lorem ipsum dolor sit amet, consectetur...</a>
						<p>Janeiro 12, 2013</p>
					</div>
					<br class="clear"/>
				</div>
				
				<div class="latest-comments last">
					<div class="image-container float-left">
						<img src="images/small_blog4.jpg" alt="image"/>
					</div>
					
					<div class="comment-text">
						<a href="blog_single.html">Class aptent taciti sociosqu.</a>
						<p>Janeiro 12, 2013</p>
					</div>
					<br class="clear"/>
				</div>
				<!-- Latest Posts Begin -->
				
				<!-- Tags Begin -->
				<h3>Tag Cloud</h3>
				<ul class="tags">
					<li><a href="#">blog</a></li>
					<li><a href="#">business</a></li>
					<li><a href="#">WordPress</a></li>
					<li><a href="#">art</a></li>
					<li><a href="#">fragrance</a></li>
					<li><a href="#">cosmetics</a></li>
					<li><a href="#">perfume</a></li>
					<li><a href="#">Yves Saint Laurent</a></li>
					<li><a href="#">eau de toilette</a></li>
				</ul>
				<!-- Tags End -->
				
			</div>
			<!-- Left Column End -->
			
			<!-- Main Column Begin -->
			<div class="main-content">
				
				<!-- Blog Entry Begin -->
				<div class="blog-entry">
				
					<div class="blog-post-title">
						<div class="blog-date float-left">
							<div class="month">Fev</div>
							<div class="date-number">23</div>
						</div>
						<div class="blog-post-title-inner">
							<a href="blog_single.html" class="title">Paco Rabanne Black XS - Perfume Masculino Eau de Toilette 100 ml</a>
						</div>
					</div>
					<br class="clear"/>
					
					<img src="images/blog1.jpg" alt="image" class="full-width-image" />
					
					<div class="user float-left">por <a href="#" class="regular">Admin</a></div>
					<div class="category float-left">postado por <a href="#" class="regular">Fotografia</a></div>
					<div class="comment float-left"><a href="#" class="regular">23 Comentários</a></div>
					<br class="clear"/>
					
					<p>Perfume masculino com fragrância enigmática e marcante que exala vigor, sensualidade e mistério. Suas notas combinam limão, baunilha, maçã, ameixa e canela. . </p>
					
					<p>Olfactive é indicado para homens conectados, ego alto e personalidade forte. Uma fragrância leve e refrescante: as primeiras notas vem com toques de mandarina e hortelã; nas notas de coração, absoluto de rosa e canela; e nas notas de fundo, acorde de couro de âmbar. O design da embalagem é perfeito: um retângulo dourado com linhas retas e simétricas com a gravação de um número de série na parte inferior, exatamente como as barras de ouro - eterno símbolo de poder para homens. Um verdadeiro objeto de desejo e de design, o Olfactive nos coloca agora perante um cruel dilema: desejamos mais o objeto ou a fragrância? A resposta parece ser clara: ambos..</p>
					<a href="blog_single.html" class="general-button"><span class="button">Leia mais</span></a>
				</div>
				<!-- Blog Entry End -->
				
				<!-- Blog Entry Begin -->
				<div class="blog-entry">
				
					<div class="blog-post-title">
						<div class="blog-date float-left">
							<div class="month">Fev</div>
							<div class="date-number">23</div>
						</div>
						<div class="blog-post-title-inner">
							<a href="blog_single.html" class="title">Aqui nova opção de informações blog.</a>
						</div>
					</div>
					<br class="clear"/>
					
					<img src="images/blog3.jpg" alt="image" class="full-width-image" />
					
					<div class="user float-left">por <a href="#" class="regular">Admin</a></div>
					<div class="category float-left">postou<a href="#" class="regular">Design</a></div>
					<div class="comment float-left"><a href="#" class="regular">12 Comentários</a></div>
					<br class="clear"/>
					
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam dui purus, pulvinar ac pellentesque faucibus et non lectus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Etiam facilisis justo vel libero faucibus at rhoncus elit condimentum.</p>
					<a href="blog_single.html" class="general-button"><span class="button">Leia mais</span></a>
				</div>
				<!-- Blog Entry End -->
				
				<!-- Blog Entry Begin -->
				<div class="blog-entry">
				
					<div class="blog-post-title">
						<div class="blog-date float-left">
							<div class="month">Fev</div>
							<div class="date-number">23</div>
						</div>
						<div class="blog-post-title-inner">
							<a href="blog_single.html" class="title">Ofertas imperdiveis você só encontra aqui, promoções de lançamento.</a>
						</div>
					</div>
					<br class="clear"/>
					
					<img src="images/blog2.jpg" alt="image" class="full-width-image" />
					
					<div class="user float-left">por <a href="#" class="regular">Admin</a></div>
					<div class="category float-left">postou <a href="#" class="regular">Foto Retouch</a></div>
					<div class="comment float-left"><a href="#" class="regular">17 Comentários</a></div>
					<br class="clear"/>
					
					<p>Nunc porta turpis vitae tellus pulvinar dapibus. Morbi ut leo sapien, vel vulte orci. Class aptent taciti pulvinar ut leo sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Suspendisse potenti. Fusce sed nisi enim, et tincidunt nunc. Nunc porta turpis vitae tellus pulvinar dapibus. Morbi ut leo sapien, vel vulte orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Suspendisse potenti. Fusce sed nisi enim, et tincidunt nunc. </p>
					
					<a href="blog_single.html" class="general-button"><span class="button">Leia mais</span></a>
				</div>
				<!-- Blog Entry End -->
				
			</div>
			<!-- Main Column End -->
			
			<br class="clear"/>
			
			<!-- List End -->
			
		</div>
		<div class="shadow"></div>
		
		<br class="clear"/>
	</div>
	
			
<? include('inc/footer.php');?>

</body>
</html>
