<!-- Gallery Begin -->
			<div class="one-half float-left">
				<h3>Consulte nossa galeria</h3>
				
				<a href="images/big01.jpg" rel="group4" class="grouped-elements" title="Lorem ipsum dolor sit amet, consecteur adipsing elit. Phasellus elefend, enim non euismod lacinia, urna odio convallis urna, eu comodo mi risus non orci.">
					<img border="0" alt="" src="images/01.jpg" class="portfolio-image">
					<span class="imagehover"></span>
				</a>
				<a href="images/big02.jpg" rel="group4" class="grouped-elements" title="Lorem ipsum dolor sit amet, consecteur adipsing elit. Phasellus elefend, enim non euismod lacinia, urna odio convallis urna, eu comodo mi risus non orci.">
					<img border="0" alt="" src="images/02.jpg" class="portfolio-image">
					<span class="imagehover"></span>
				</a>
				<a href="images/big03.jpg" rel="group4" class="grouped-elements" title="Lorem ipsum dolor sit amet, consecteur adipsing elit. Phasellus elefend, enim non euismod lacinia, urna odio convallis urna, eu comodo mi risus non orci.">
					<img border="0" alt="" src="images/03.jpg" class="portfolio-image">
					<span class="imagehover"></span>
				</a>
				<a href="images/big04.jpg" rel="group4" class="grouped-elements" title="Lorem ipsum dolor sit amet, consecteur adipsing elit. Phasellus elefend, enim non euismod lacinia, urna odio convallis urna, eu comodo mi risus non orci.">
					<img border="0" alt="" src="images/04.jpg" class="portfolio-image">
					<span class="imagehover"></span>
				</a>
				<a href="images/big05.jpg" rel="group4" class="grouped-elements" title="Lorem ipsum dolor sit amet, consecteur adipsing elit. Phasellus elefend, enim non euismod lacinia, urna odio convallis urna, eu comodo mi risus non orci.">
					<img border="0" alt="" src="images/05.jpg" class="portfolio-image">
					<span class="imagehover"></span>
				</a>
				<a href="images/big06.jpg" rel="group4" class="grouped-elements" title="Lorem ipsum dolor sit amet, consecteur adipsing elit. Phasellus elefend, enim non euismod lacinia, urna odio convallis urna, eu comodo mi risus non orci.">
					<img border="0" alt="" src="images/06.jpg" class="portfolio-image">
					<span class="imagehover"></span>
				</a>
				<a href="images/big03.jpg" rel="group4" class="grouped-elements" title="Lorem ipsum dolor sit amet, consecteur adipsing elit. Phasellus elefend, enim non euismod lacinia, urna odio convallis urna, eu comodo mi risus non orci.">
					<img border="0" alt="" src="images/03.jpg" class="portfolio-image">
					<span class="imagehover"></span>
				</a>
				<a href="images/big01.jpg" rel="group4" class="grouped-elements" title="Lorem ipsum dolor sit amet, consecteur adipsing elit. Phasellus elefend, enim non euismod lacinia, urna odio convallis urna, eu comodo mi risus non orci.">
					<img border="0" alt="" src="images/01.jpg" class="portfolio-image">
					<span class="imagehover"></span>
				</a>
				<a href="images/big04.jpg" rel="group4" class="grouped-elements" title="Lorem ipsum dolor sit amet, consecteur adipsing elit. Phasellus elefend, enim non euismod lacinia, urna odio convallis urna, eu comodo mi risus non orci.">
					<img border="0" alt="" src="images/04.jpg" class="portfolio-image">
					<span class="imagehover"></span>
				</a>
			</div>
			<!-- Gallery End -->
