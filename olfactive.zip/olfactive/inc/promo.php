		<!-- Promo Begin -->
		<div class="promo-inner" id="promo">
		
			<!-- main navigator -->
			
			<ul id="main_navi">
			
				<li class="first">
					<img src="images/slide_small1.jpg">
					<span class="title">What Is My Color</span>
					Lorem ipsum dolor sit amet
				</li>
				<li class="">
					<img src="images/slide_small2.jpg">
					<span class="title">Full Set Of Features</span>
					Nulla sit amet nunc non nibh faucibus
				</li>
				<li class="active">
					<img src="images/slide_small3.jpg">
					<span class="title">Dreams In Purple</span>
					Phasellus elefend, enim non euismod lacinia
				</li>
				<li class="last">
					<img src="images/slide_small4.jpg">
					<span class="title">Red For Passion</span>
					Class aptent taciti sociosqu it litora
				</li>
			</ul>
			
			<!-- root element for the main scrollable -->
			<div id="main">
			
				<!-- root element for pages -->
				<div style="top: -940px;" id="pages">
			
					<!-- page #1 -->
					<div class="page">
			
						<!-- sub navigator #1 -->
						<div class="navi"><a class="nivo-control active"></a><a></a><a></a></div>
			
						<!-- inner scrollable #1 -->
						<div class="scrollable">
			
							<!-- root element for scrollable items -->
							<div class="items">
			
								<!-- items  -->
								<div class="item">
									<img src="images/promo1.jpg">
								</div>
								<div class="item">
									<img src="images/promo4.jpg">
								</div>
								<div class="item">
									<img src="images/promo5.jpg">
								</div>
			
								</div>
			
						</div>
			
					</div>
			
					<!-- page #2 -->
					<div class="page">
			
						<div class="navi"><a class="active"></a><a></a><a></a></div>
			
						<!-- inner scrollable #2 -->
						<div class="scrollable">
			
							<!-- root element for scrollable items -->
							<div class="items">
			
								<!-- items on the second page -->
							<div class="item">
									<img src="images/promo2.jpg">
								</div>
								<div class="item">
									<img src="images/promo4.jpg">
								</div>
								<div class="item">
									<img src="images/promo5.jpg">
								</div>
			
							</div>
			
						</div>
			
					</div>
					
					<!-- page #3 -->
					<div class="page">
			
						<div class="navi"><a class="active"></a><a></a><a></a></div>
			
						<!-- inner scrollable #2 -->
						<div class="scrollable">
			
							<!-- root element for scrollable items -->
							<div class="items">
			
								<!-- items on the second page -->
								<div class="item">
									<img src="images/promo4.jpg">
								</div>
								<div class="item">
									<img src="images/promo2.jpg">
								</div>
								<div class="item">
									<img src="images/promo5.jpg">
								</div>
			
							</div>
			
						</div>
			
					</div>
			
					<!-- page #4 -->
					<div class="page">
			
						<div class="navi"><a class="active"></a><a></a><a></a></div>
			
						<!-- inner scrollable #3 -->
						<div class="scrollable">
			
							<!-- root element for scrollable items -->
							<div class="items">
			
								<!-- items on the first page -->
							<div class="item">
									<img src="images/promo3.jpg">
								</div>
								<div class="item">
									<img src="images/promo4.jpg">
								</div>
								<div class="item">
									<img src="images/promo5.jpg">
								</div>
			
							</div>
			
						</div>
			
					</div>
					<!-- End page 4 -->
					
				</div>
			
			</div>

		</div>
		<!-- End Promo -->



		<div class="shadow"></div>
		<!-- Promo End -->
		
