<!-- Recent Posts Begin -->
			<div class="one-half float-right">
				<h3>Ultimas notícias ou mensagens de blog</h3>
				
				<div class="blog-post-home-title">
					<div class="blog-home-date float-left">
						<div class="date-number">23<br/>Feb</div>
					</div>
					<div class="blog-post-home-title-inner">
						<a href="blog_single.html" class="title">Lorem ipsum dolor sit amet, consectetur elit. Nulla sit amet nunc non nibh faucibus dictum.</a>
					</div>
				</div>
				
				<p class="post-content">
				Lorem ipsum dolor sit amet, consecteur adipsing elit. Phasellus elefend, enim non euismod lacinia, urna odio convallis urna, eu comodo mi risus non orci. Nullam eu sapien ipsum, non adipiscing lacus. Suspendisse tempus purus et diam consequat volutpat. <a href="blog_single.html" class="regular">Leia mais...</a>
				</p>
				
				<div class="blog-post-home-title">
					<div class="blog-home-date float-left">
						<div class="date-number">20<br/>Feb</div>
					</div>
					<div class="blog-post-home-title-inner">
						<a href="blog_single.html" class="title">Integer mattis accumsan dui vel sodales. In id ante lobortis nisi pretium pretium.</a>
					</div>
				</div>
				
				<p class="post-content-last">
				Nunc porta turpis vitae tellus pulvinar dapibus. Morbi ut leo sapien, vel vulte orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Suspendisse potenti. <a href="blog_single.html" class="regular">Leia mais...</a>
				</p>
			</div>
			<br class="clear"/>
		</div>
		<!-- Recent Posts End -->
