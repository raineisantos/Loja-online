
		<!-- Message Begin -->
		
		<div class="message">
			Bem-vindo a este grande e sofisticado e-shop. Nós preparamos um enorme conjunto de funcionalidades para você!
		</div>
		
		<!-- Message End -->
