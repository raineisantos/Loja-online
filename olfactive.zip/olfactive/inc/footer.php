<div id="footer">
		<div class="footer-main">
			
			<div class="back-to-top"><a href="#top"><img src="images/top.png" alt="Back to top" border="0"/></a></div>
			
			<!-- Footer Column 1 Begin -->
			<div class="left-column float-left">
				<h5>Menu de navegação</h5>
				<ul class="footer-nav">
					<li class="first"><a href="#">Suporte ao cliente </a></li>
					<li><a href="#">Informações da Loja</a></li>
					<li><a href="#">Termos de contrato</a></li>
					<li><a href="#">Notícia legal</a></li>
					<li><a href="cadastro.php">Cadastro</a></li>
					<li><a href="#">FAQ</a></li>
				</ul>
			</div>
			<!-- Footer Column 1 End -->
			
			<!-- Footer Column 2 Begin -->
			<div class="middle-column float-left">
				<h5>Newsletter</h5>
				<p>Assine a nossa newsletter para receber atualizações regulares sobre uma base, ofertas quentes, site de notícias, etc.</p>
				<p class="newsletter">
					<input type="text" value="Digite seu e-mail..." onfocus="if(this.value=='Digite seu e-mail...'){this.value=''};" onblur="if(this.value==''){this.value='Digite seu e-mail...'};" class="newsletter-field"/>
					<input type="submit" id="go" value="GO" class="go-btn"/>
				</p>
			</div>
			<!-- Footer Column 2 End -->
			
			<!-- Footer Column 3 Begin -->
			<div class="left-column float-right">
				<h5>Contato </h5>
				<p>Aracaju - SE, Brasil<br/>
					Rua da pororoca ,24 Siqueira Campos , Edf: 9006
				</p>
				<p>
					Telefone: +55 79 1234 4567 e +55 79 456 789<br/>
					Fax: +55 79 1234 4567<br/>
					Email: <a href="#" class="footerlink">contato@olfactive.com</a><br/>
				</p>
				<p>
					<a href="#" class="social"><img src="images/facebook.png" alt="facebook" border="0"/></a>
					<a href="#" class="social"><img src="images/vimeo.png" alt="vimeo" border="0"/></a>
					<a href="#" class="social"><img src="images/youtube.png" alt="youtube" border="0"/></a>
					<a href="#" class="social"><img src="images/twitter.png" alt="twitter" border="0"/></a>
					<a href="#" class="social"><img src="images/google.png" alt="google" border="0"/></a>
				</p>
			</div>
			<!-- Footer Column 3 End -->







		</div>
	</div>

</div>

