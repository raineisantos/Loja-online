<!-- Navigation start -->
			<ul class="sf-menu">
				<li class="nav-item"><a href="#">Home</a>
					<ul>
						<li class="sfish-navgiation-item">
							<a href="price_compare.php">Compare preços na tabela</a>
						</li>
						<li class="sfish-navgiation-item">
							<a href="faq.php">FAQ</a>
						</li>
						<li class="sfish-navgiation-item">
							<a href="cart.php">Shopping Cart</a>
						</li>
						<li class="sfish-navgiation-item">
							<a href="right_sidebar.php">Right Sidebar</a>
						</li>
					</ul>	
				</li>
				<li class="nav-item"><a href="blog.php">Blog</a></li>
				<li class="nav-item"><a href="#">Linha Capilar</a>
					<ul>
						<li class="sfish-navgiation-item">
							<a href="shortcodes_buttons.html">Shampoo liquido</a>
						</li>
						<li class="sfish-navgiation-item">
							<a href="shortcodes_columns.html">Shampoo em barras</a>
						</li>
						<li class="sfish-navgiation-item last">
							<a href="shortcodes_tabs.html">Shampoo em pó</a>
						</li>
					</ul>	
				</li>
				<li class="nav-item"><a href="#">Hidratantes</a>
					<ul>
						<li class="sfish-navgiation-item">
							<a href="portfolio_2columns.html">Para as mãos </a>
						</li>
						<li class="sfish-navgiation-item">
							<a href="portfolio_3columns.html">Para os pés</a>
						</li>
						<li class="sfish-navgiation-item last">
							<a href="portfolio_4columns.html">Para o corpo</a>
						</li>
					</ul>
				</li>
				<li class="nav-item"><a href="contacts.php">Contato</a></li>
			</ul>
			<!-- Navigation end -->
