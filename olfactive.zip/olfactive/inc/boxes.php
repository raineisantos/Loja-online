<!-- Bullet List Begin -->
		<div class="bullet-list float-left">
			<h4>Fornecendo produtos de alta qualidade</h4>
			<p>Nunc porta turpis vitae tellus pulvinar dapibus. Morbi ut leo sapien, vel vulte orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>
			<ul class="bullet-list">
				<li class="first">Suspendisse potenti. Fusce sed nisi enim, et tincidunt nunc</li>
				<li>Vestibulum sed sapien quam, et iaculis ipsum</li>
				<li>Lorem ipsum dolor sit amet, elit.</li>
				<li>Phasellus eleifend, enim non esmod lacinia, urna odio convallis urna</li>
			</ul>
		</div>
		<!-- Bullet List End -->
		
		<!-- Bullet List Begin -->
		<div class="bullet-list float-right">
			<h4>Muitos produtos</h4>
			<p class="icon-list-1">Lorem ipsum dolor amet, consecteur adipsing elit. Phasellus efend, enim non euismod lacinia, urna odio convallis urna, eu comodo mi non orci. Nullam eu sapien ipsum, non adipiscing lacus.</p>
			<p class="icon-list-2">Nunc porta turpis vitae tellus pulvinar dapibus. Morbi ut leo sapien, vel vulte orci. Class sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Suspendisse potenti. </p>
			<p class="icon-list-3">Sed aliquet urna eu diam malesuada egestas nisl faucibus. Vivamus dui libero, pharetra eget vehicula vel, laoreet a arcu. Sed ac mauris massa. Praesent rutrum condimentum dolor.</p>
		</div>
		<!-- Bullet List End -->
